namespace Copa.OCC.Api.Domain.Enums;

public enum FlightStatus
{
    Scheduled,
    InTransit,
    Delayed,
    Cancelled,
    Landed
}
