namespace Copa.OCC.Api.Domain.Enums;

public enum ServiceAvailability
{
    Available,
    Degraded,
    Unavailable
}
